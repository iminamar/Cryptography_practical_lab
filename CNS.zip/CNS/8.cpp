#include <iostream>
#include <cstring>

void performBitwiseOperations(char* str) {
    int len = std::strlen(str);

    std::cout << "Performing Bitwise AND with '0': ";
    for (int i = 0; i < len; ++i) {
        char result = str[i] & 0;
        std::cout << result;
    }
    std::cout << std::endl;

    std::cout << "Performing Bitwise OR with '0': ";
    for (int i = 0; i < len; ++i) {
        char result = str[i] | 0;
        std::cout << result;
    }
    std::cout << std::endl;

    std::cout << "Performing Bitwise XOR with '0': ";
    for (int i = 0; i < len; ++i) {
        char result = str[i] ^ 0;
        std::cout << result;
    }
    std::cout << std::endl;

    std::cout << "Performing Bitwise AND with '127': ";
    for (int i = 0; i < len; ++i) {
        char result = str[i] & 127;
        std::cout << result;
    }
    std::cout << std::endl;

    std::cout << "Performing Bitwise OR with '127': ";
    for (int i = 0; i < len; ++i) {
        char result = str[i] | 127;
        std::cout << result;
    }
    std::cout << std::endl;

    std::cout << "Performing Bitwise XOR with '127': ";
    for (int i = 0; i < len; ++i) {
        char result = str[i] ^ 127;
        std::cout << result;
    }
    std::cout << std::endl;
}

int main() {
    char str[] = "zameer";

    std::cout << "Original String: " << str << std::endl;

    performBitwiseOperations(str);

    return 0;
}
