#include<iostream>
using namespace std;

double squareroot(double num)
{
    if(num<2)
        return num;
    double y=num;
    double z =(y+(num/y))/2;
    while(abs(y-z)>=0.0001)
    {
        y=z;
        z= (y+(num/y))/2;
    }
    return z;
}

int main()
{
    double num;
    cout<<"Enter a number: ";
    cin>>num;
    cout<<"Square root is: "<<squareroot(num);
    return 0;
}