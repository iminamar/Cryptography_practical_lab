#include<iostream>
using namespace std;

int prime(int a, int b)
{
    int mx = max(a,b);
    while(1){
        if(mx%a==0 && mx%b==0)
        {
            return mx;
        }
        ++mx;
    }
    return 1;
}

int gcd(int a, int b)
{
    int gcd, lcm;;
    for(int i=1; i<=a && i<=b; ++i)
    {
        if(a%i==0 && b%i==0)
            gcd =i;
    }
    lcm = (a*b)/gcd;
    return lcm;
}

int main()
{
    int n1, n2;
    cout<<"Enter two positive integers: ";
    cin>>n1>>n2;
    int x;
    cout<<"Enter 0 for primefactorisation and 1 for gcd method: ";
    cin>>x;
    if(x==0)
    {
        cout<<prime(n1, n2);
    }
    else if(x==1)
    {
        cout<<gcd(n1,n2);
    }
    return 0;
}