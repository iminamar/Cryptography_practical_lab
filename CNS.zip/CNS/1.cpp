#include <iostream>
using namespace std;
int main()
{
    string a;
    int b;
    cout<<"enter the string";
    cin>>a;
    cout<<"enter the shift";
    cin>>b;
    for(int i=0; i<a.length(); i++)
    {
        if(islower(a[i]))
        {
            a[i] = char(int(a[i]+b-97)%26+97);
        }
        if(isupper(a[i]))
        {
            a[i] = char(int(a[i]+b-65)%26+65);
        }

    }
    cout<<endl<<a;
    return 0;
}