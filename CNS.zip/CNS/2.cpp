#include <iostream>
#include <set>

int main() {
    std::set<int> A = {0, 1, 4, 6, 8};
    std::set<int> B = {2, 3, 5, 6, 7, 8};

    std::set<int> unionSet(A.begin(), A.end());
    unionSet.insert(B.begin(), B.end());

    std::set<int> intersectionSet;
    for (auto elem : A) {
        if (B.count(elem) > 0) {
            intersectionSet.insert(elem);
        }
    }

    std::set<int> differenceSet;
    for (auto elem : A) {
        if (B.count(elem) == 0) {
            differenceSet.insert(elem);
        }
    }

    std::cout << "Union of A and B: ";
    for (auto elem : unionSet) {
        std::cout << elem << " ";
    }
    std::cout << std::endl;

    std::cout << "Intersection of A and B: ";
    for (auto elem : intersectionSet) {
        std::cout << elem << " ";
    }
    std::cout << std::endl;

    std::cout << "Difference of A and B: ";
    for (auto elem : differenceSet) {
        std::cout << elem << " ";
    }
    std::cout << std::endl;

    return 0;
}
