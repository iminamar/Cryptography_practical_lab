#include <iostream>
#include <string>
#include <vector>

// Function to encrypt a plaintext using a key matrix
std::string encrypt(const std::string& plaintext, const std::vector<std::vector<int>>& keyMatrix) {
    std::string ciphertext;
    int keySize = keyMatrix.size();

    // Pad the plaintext with 'X' if its length is not divisible by the key size
    std::string paddedPlaintext = plaintext;
    int paddingLength = keySize - (paddedPlaintext.length() % keySize);
    for (int i = 0; i < paddingLength; i++) {
        paddedPlaintext += 'X';
    }

    for (int i = 0; i < paddedPlaintext.length(); i += keySize) {
        std::vector<int> plainChars;
        std::vector<int> encryptedChars;

        // Convert the current block of plaintext characters to their respective numeric values
        for (int j = 0; j < keySize; j++) {
            plainChars.push_back(paddedPlaintext[i + j] - 'A');
        }

        // Perform matrix multiplication to get the corresponding ciphertext values
        for (int j = 0; j < keySize; j++) {
            int encryptedChar = 0;
            for (int k = 0; k < keySize; k++) {
                encryptedChar += keyMatrix[j][k] * plainChars[k];
            }
            encryptedChars.push_back(encryptedChar % 26);
        }

        // Convert the encrypted numeric values back to characters and append them to the ciphertext
        for (int j = 0; j < keySize; j++) {
            ciphertext += static_cast<char>(encryptedChars[j] + 'A');
        }
    }

    return ciphertext;
}

// Function to decrypt a ciphertext using a key matrix
std::string decrypt(const std::string& ciphertext, const std::vector<std::vector<int>>& keyMatrix) {
    std::string plaintext;
    int keySize = keyMatrix.size();

    for (int i = 0; i < ciphertext.length(); i += keySize) {
        std::vector<int> encryptedChars;
        std::vector<int> decryptedChars;

        // Convert the current block of ciphertext characters to their respective numeric values
        for (int j = 0; j < keySize; j++) {
            encryptedChars.push_back(ciphertext[i + j] - 'A');
        }

        // Perform matrix multiplication with the inverse of the key matrix to get the corresponding plaintext values
        for (int j = 0; j < keySize; j++) {
            int decryptedChar = 0;
            for (int k = 0; k < keySize; k++) {
                decryptedChar += keyMatrix[j][k] * encryptedChars[k];
            }
            decryptedChars.push_back(decryptedChar % 26);
        }

        // Convert the decrypted numeric values back to characters and append them to the plaintext
        for (int j = 0; j < keySize; j++) {
            plaintext += static_cast<char>(decryptedChars[j] + 'A');
        }
    }

    return plaintext;
}

int main() {
    std::string plaintext;
    std::string key;

    // Prompt the user to enter the plaintext
    std::cout << "Enter the plaintext: ";
    std::getline(std::cin, plaintext);

    // Prompt the user to enter the key
    std::cout << "Enter the key: ";
   std::getline(std::cin, key);

    // Convert the key to uppercase
    for (char& c : key) {
        c = std::toupper(c);
    }

    // Calculate the key matrix based on the key
    int keySize = key.length();
    std::vector<std::vector<int>> keyMatrix(keySize, std::vector<int>(keySize, 0));
    for (int i = 0; i < keySize; i++) {
        for (int j = 0; j < keySize; j++) {
            keyMatrix[i][j] = key[(i + j) % keySize] - 'A';
        }
    }

    // Encrypt the plaintext using the key matrix
    std::string ciphertext = encrypt(plaintext, keyMatrix);
    std::cout << "Ciphertext: " << ciphertext << std::endl;

    // Decrypt the ciphertext using the key matrix
    std::string decryptedText = decrypt(ciphertext, keyMatrix);
    std::cout << "Decrypted text: " << decryptedText << std::endl;

    return 0;
}
