#include <iostream>
#include <string>

// Function to encrypt a plaintext using the Vigenère cipher with Caesar cipher as a component
std::string encrypt(const std::string& plaintext, const std::string& key) {
    std::string ciphertext;
    int keyLength = key.length();
    int keyIndex = 0;
    
    for (char plainChar : plaintext) {
        if (std::isalpha(plainChar)) {
            // Determine the shift for the current character in the plaintext using the key
            int shift = key[keyIndex] - 'A';
            
            // Apply the shift using the Caesar cipher
            char encryptedChar = 'A' + (plainChar - 'A' + shift) % 26;
            ciphertext += encryptedChar;
            
            // Move to the next character in the key
            keyIndex = (keyIndex + 1) % keyLength;
        }
    }
    
    return ciphertext;
}

// Function to decrypt a ciphertext using the Vigenère cipher with Caesar cipher as a component
std::string decrypt(const std::string& ciphertext, const std::string& key) {
    std::string plaintext;
    int keyLength = key.length();
    int keyIndex = 0;
    
    for (char cipherChar : ciphertext) {
        if (std::isalpha(cipherChar)) {
            // Determine the shift for the current character in the ciphertext using the key
            int shift = key[keyIndex] - 'A';
            
            // Reverse the shift using the Caesar cipher to get the original plaintext character
            char decryptedChar = 'A' + (cipherChar - 'A' - shift + 26) % 26;
            plaintext += decryptedChar;
            
            // Move to the next character in the key
            keyIndex = (keyIndex + 1) % keyLength;
        }
    }
    
    return plaintext;
}

int main() {
    std::string plaintext = "HELLO";
    std::string key = "KEY";
    
    std::string ciphertext = encrypt(plaintext, key);
    std::cout << "Ciphertext: " << ciphertext << std::endl;
    
    std::string decryptedText = decrypt(ciphertext, key);
    std::cout << "Decrypted text: " << decryptedText << std::endl;
    
    return 0;
}
