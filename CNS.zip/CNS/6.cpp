#include <iostream>

void extendedEuclidean(int a, int b, int& s, int& t) {
    if (b == 0) {
        s = 1;
        t = 0;
    } else {
        int q = a / b;
        int r = a % b;
        int s1, t1;
        extendedEuclidean(b, r, s1, t1);
        s = t1;
        t = s1 - q * t1;
    }
}

int main() {
    int a, b;

    std::cout << "Enter two integers (a and b): ";
    std::cin >> a >> b;

    int s, t;
    extendedEuclidean(a, b, s, t);

    std::cout << "s = " << s << ", t = " << t << std::endl;

    return 0;
}
