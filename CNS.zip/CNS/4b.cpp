#include <iostream>

double squareroot(double num) {
    if (num < 2)
        return num;
    double y = num;
    double z = (y + (num / y)) / 2;
    while (std::abs(y - z) >= 0.0001) {
        y = z;
        z = (y + (num / y)) / 2;
    }
    return z;
}

bool isPrime(long int number) {
    if (number < 2)
        return false;
    double sqrtNumber = squareroot(number);
    for (long int i = 2; i <= sqrtNumber; ++i) {
        if (number % i == 0) {
            return false;
        }
    }
    return true;
}

int main() {
    long int largeNumber;

    std::cout << "Enter a large integer number: ";
    std::cin >> largeNumber;

    if (isPrime(largeNumber)) {
        std::cout << "The number is prime." << std::endl;
    } else {
        std::cout << "The number is not prime." << std::endl;
    }

    return 0;
}
