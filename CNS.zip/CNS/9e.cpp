// myheader.h
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;

int main(){
    //ENCRYPTION
    int t,n,m,i,j,k,sum=0;
    string s;
    cout<<"Enter the message"<<'\n';
    cin>>s;
    cout<<"Enter key"<<'\n';
    cin>>n;
    vector<vector<char>> a(n,vector<char>(s.size(),' '));
    j=0;
    int flag=0;
    for(i=0;i<s.size();i++){
        a[j][i] = s[i];
         if(j==n-1){
            flag=1;
        }
        else if(j==0)
            flag=0;

        if(flag==0){
            j++;
        }
        else j--;
    }
    for(i=0;i<n;i++){
        for(j=0;j<s.size();j++){
            if(a[i][j]!=' ')
                cout<<a[i][j];
        }
    }
    cout<<'\n';   


    //DECRYPTION
    int t1,n1,m1,i1,j1,k1,sum1=0;
    string s1;
    cout<<"Enter the message to decrypt"<<'\n';
    cin>>s1;
    cout<<"Enter key"<<'\n';
    cin>>n1;
    vector<vector<char>> a1(n1,vector<char>(s1.size(),' '));
    j1=0;
    int flag1=0;
    for(i1=0;i1<s1.size();i1++){
        a1[j1][i1] = '0';
         if(j1==n1-1){
            flag1=1;
        }
        else if(j1==0)
            flag1=0;
        if(flag1==0){
            j1++;
        }
        else j1--;
    }
    int temp =0;
    for(i1=0;i1<n1;i1++){
        for(j1=0;j1<s1.size();j1++){
                if(a1[i1][j1]=='0')
                    a1[i1][j1]= s1[temp++];
        }
    }
    flag1=0;
    j1=0;
    for(i1=0;i1<s1.size();i1++){
        cout<<a1[j1][i1];
         if(j1==n1-1){
            flag1=1;
        }
        else if(j1==0)
            flag1=0;
        if(flag1==0){
            j1++;
            
        }
        else j1--;
    }
    cout<<'\n'; 



    return 0;
}