#include <iostream>

bool isDivisibleByAll(long int number) {
    for (int divisor = 2; divisor <= 15; ++divisor) {
        if (number % divisor != 0) {
            return false;
        }
    }
    return true;
}

int main() {
    long int largeNumber;

    std::cout << "Enter a large integer number: ";
    std::cin >> largeNumber;

    if (isDivisibleByAll(largeNumber)) {
        std::cout << "The number is divisible by all numbers from 2 to 15." << std::endl;
    } else {
        std::cout << "The number is not divisible by all numbers from 2 to 15." << std::endl;
    }

    return 0;
}
